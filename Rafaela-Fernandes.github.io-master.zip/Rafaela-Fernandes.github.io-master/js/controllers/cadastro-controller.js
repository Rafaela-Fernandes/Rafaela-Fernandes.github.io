angular.module('formulario').controller('CadastroController', function ($scope, $http, $localStorage) {

 

    var dados; // variavel pra guadar o retorno do json db.json

    $http.get('db.json').success(function (data) {
        dados = data;
        //console.log(dados);
        localStorage.setItem("Cadastro", JSON.stringify(dados));
    }); // usando metodo get para retornar os arquivos json e guadar na variavel dados.





    $scope.cadastro = {

    }; // obejto cadastro criado 



     
  

    $scope.salvarDados = function () {
        
         if($scope.formCadastro.$valid){
               $scope.alerta = false
                 dados.push($scope.cadastro); // jogando dados dos cadastro na variavel "dados", que ja contem os demais dados
        localStorage.setItem("Cadastro", JSON.stringify(dados)); // setando intens na váriavel  dados, onde ja contes os demais dados armazenado     
         
        
        $scope.cadastro = {}; // zerando os campos
         }else{
             
              $scope.alerta = true
             
         }
    
    };

    


}); // fim da funçao que fara submetarar o form 