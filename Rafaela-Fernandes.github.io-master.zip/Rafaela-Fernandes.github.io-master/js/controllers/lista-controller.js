angular.module('formulario').controller('ListaController', function ($scope, $http, $localStorage) {




    var dado = localStorage.getItem('Cadastro'); // retornando dados do localstorage
    $scope.dados = JSON.parse(dado);


    $scope.filtro = ''; // variavel que gurda oq foi digitado pelo usuario, pega com ng-model.
    
    /* removendo item, porem correto seria usando função de remover do localstorage mas n conseguir */
    $scope.remover = function () {
        var index = $scope.dados.indexOf(this.dados);
        $scope.dados.splice(index, 1);
        localStorage.removeItem('index');
        //console.log(localStorage.removeItem('Cadastro'));

    }



});