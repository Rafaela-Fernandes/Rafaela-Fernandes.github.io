
/* module pricinpical , que ira inicializar a aplicacao */


angular.module('formulario',['minhasDiretivas','ngAnimate','ngRoute','ngStorage','angular.viacep','ngMask'])
.config(function($routeProvider) {

	

		$routeProvider.when('/cadastro', {
			templateUrl: 'paginas/cadastro.html',
            controller:'CadastroController'
		})

       $routeProvider.when('/lista', {
			templateUrl: 'paginas/lista.html',
            controller: 'ListaController'
		});
	
		
    
     $routeProvider.otherwise({redirectTo: '/cadastro'});

	});