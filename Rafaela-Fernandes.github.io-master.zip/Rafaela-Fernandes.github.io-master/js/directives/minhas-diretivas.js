angular.module('minhasDiretivas',[])
.directive('navMenu',function(){
    
    var ddo ={
        
    }
    
    
    ddo.restrict = "AE";
    ddo.transclude =false;
    
    ddo.templateUrl = 'js/directives/nav-menu.html';
    
    
    return ddo;
})
.directive('navLateral',function(){
    
    var ddo ={
        
    }
    
    
    ddo.restrict = "AE";
    ddo.transclude =false;
    
    ddo.templateUrl = 'js/directives/nav-lateral.html';
    
    
    return ddo;
})